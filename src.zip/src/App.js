import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { Switch, Route } from 'react-router-dom';
import Login from './Login';
import SignUpComponent from './components/Signup';
import { MuiThemeProvider } from "material-ui/styles";
import { AppBar,  } from "material-ui";
import home, { HomeComponent } from './components/home/home';

class App extends Component{


render(){
  return (<div>
            <MuiThemeProvider>
                <div>
                    <AppBar title="Application Name">
                    
                    </AppBar>
    <Switch>
      
      <Route path="/signup" component={SignUpComponent}/>
      <Route path="/home" component={home}/>
      <Route path="/" exact component={Login}/>
    </Switch>
    </div>
            </MuiThemeProvider>
        
  </div>);
}

}

export default App;
